<template>
  <h1>Oops! You hit a path that doesn't exist.</h1>
</template>
