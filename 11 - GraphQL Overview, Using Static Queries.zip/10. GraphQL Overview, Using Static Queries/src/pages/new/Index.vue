<template>
  <Default>
    <h1>New index</h1>
  </Default>
</template>

<script>
import Default from "~/layouts/Default.vue";

export default {
  components: {
    Default
  }
};
</script>