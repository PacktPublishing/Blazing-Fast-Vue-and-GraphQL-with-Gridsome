export default {
  "touchiconMimeType": null,
  "faviconMimeType": null,
  "precomposed": false,
  "touchicons": [],
  "favicons": []
}