export default {
  "siteUrl": "",
  "siteName": "Vue Couture",
  "titleTemplate": "%s - Vue Couture",
  "siteDescription": "Your one-stop shop for finding all manner of stylish, luxury apparel and accessories",
  "version": "0.6.2"
}