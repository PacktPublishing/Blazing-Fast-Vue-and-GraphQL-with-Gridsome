export default {
  "siteUrl": "",
  "siteName": "Gridsome",
  "titleTemplate": "%s - Gridsome",
  "siteDescription": "",
  "version": "0.6.2"
}