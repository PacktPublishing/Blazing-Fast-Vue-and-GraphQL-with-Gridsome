<template>
  <h1>New Products</h1>
</template>
