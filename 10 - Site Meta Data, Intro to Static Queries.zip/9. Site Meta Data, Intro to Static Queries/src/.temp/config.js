export default {
  "siteUrl": "",
  "siteName": "Vue Couture",
  "titleTemplate": "%s - Vue Couture",
  "siteDescription": "",
  "version": "0.6.2"
}