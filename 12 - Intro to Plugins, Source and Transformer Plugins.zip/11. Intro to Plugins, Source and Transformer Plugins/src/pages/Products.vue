<template>
  <Layout>
    <h1>Products</h1>
  </Layout>
</template>

<script>
export default {
  metaInfo: {
    title: "Products",
    meta: [
      { charset: "utf-8" },
      { name: "author", content: "Code Artistry" },
      {
        name: "description",
        content:
          "Discover our entire range of luxury apparel, shoes, and accessories"
      },
      {
        name: "keywords",
        content: "Premium Jackets, High-End Clothing, Designer Sunglasses"
      }
    ]
  }
};
</script>
