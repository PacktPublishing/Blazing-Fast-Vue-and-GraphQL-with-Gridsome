<template>
  <h1>Products</h1>
</template>
