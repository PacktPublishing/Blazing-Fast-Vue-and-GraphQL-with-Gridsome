<template>
  <h1>New index</h1>
</template>
