<template>
  <Layout>
    <h1>Products</h1>
  </Layout>
</template>
